package com.ezen.myapp.domain;

public class BoardVo {

	private int bidx;
	private String subject;
	private String contents;
	private int viewcount;
	private String writeday;
	private String ip;
	private String bdelyn;
	private String pwd;
	private int midx;
	private String membernickname;
	private String membermbti;
	
	
	public String getMembernickname() {
		return membernickname;
	}
	public void setMembernickname(String membernickname) {
		this.membernickname = membernickname;
	}
	public String getMembermbti() {
		return membermbti;
	}
	public void setMembermbti(String membermbti) {
		this.membermbti = membermbti;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getBidx() {
		return bidx;
	}
	public void setBidx(int bidx) {
		this.bidx = bidx;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public int getViewcount() {
		return viewcount;
	}
	public void setViewcount(int viewcount) {
		this.viewcount = viewcount;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getBdelyn() {
		return bdelyn;
	}
	public void setBdelyn(String bdelyn) {
		this.bdelyn = bdelyn;
	}
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	
}
