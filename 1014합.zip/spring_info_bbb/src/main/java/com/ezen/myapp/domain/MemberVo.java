package com.ezen.myapp.domain;

public class MemberVo {
	
	private int midx;
	private String memberid;
	private String memberpwd;
	private String membername;
	private String membergender;
	private long memberbirth;
	private String memberaddr;
	private long memberphone;
	private String membermbti;
	private String writeday;
	private String membernickname;
	private String mdelyn;
	private String memberemail;
	
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMemberpwd() {
		return memberpwd;
	}
	public void setMemberpwd(String memberpwd) {
		this.memberpwd = memberpwd;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembergender() {
		return membergender;
	}
	public void setMembergender(String membergender) {
		this.membergender = membergender;
	}
	public long getMemberbirth() {
		return memberbirth;
	}
	public void setMemberbirth(long memberbirth) {
		this.memberbirth = memberbirth;
	}
	public String getMemberaddr() {
		return memberaddr;
	}
	public void setMemberaddr(String memberaddr) {
		this.memberaddr = memberaddr;
	}
	public long getMemberphone() {
		return memberphone;
	}
	public void setMemberphone(long memberphone) {
		this.memberphone = memberphone;
	}
	public String getMembermbti() {
		return membermbti;
	}
	public void setMembermbti(String membermbti) {
		this.membermbti = membermbti;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getMembernickname() {
		return membernickname;
	}
	public void setMembernickname(String membernickname) {
		this.membernickname = membernickname;
	}
	public String getMdelyn() {
		return mdelyn;
	}
	public void setMdelyn(String mdelyn) {
		this.mdelyn = mdelyn;
	}
	public String getMemberemail() {
		return memberemail;
	}
	public void setMemberemail(String memberemail) {
		this.memberemail = memberemail;
	}
	
	

}
