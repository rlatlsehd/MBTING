package com.fish.myapp.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fish.myapp.domain.BoardVo;
import com.fish.myapp.service.BoardService;


@Controller
public class BoardController {
	
	@Autowired
	BoardService bs;
	
	@RequestMapping(value = "/board/boardtest.do")
	public String boardtest() {
		
		return "board/boardtest";
		
	}
	
	@RequestMapping(value = "/board/boardList.do")
	public String boardList(Model model) {
		
		ArrayList<BoardVo> alist = 	bs.boardSelectAll();
		model.addAttribute("alist", alist);		
		
		return "/board/boardList";
	}
	
	@RequestMapping(value = "/board/boardContents.do")
	public String boardView(@RequestParam("bidx") int bidx,		
			Model model) throws ParseException {		
		
		//bidx�� �Ѱ��ְ� ������ �����͸� ��������
		BoardVo bv = bs.boardSelectOne(bidx);
		//�𵨿� ��ư����� ȭ������ �Ѱ��ش�
		model.addAttribute("bv", bv);
		
		return "board/boardContents";
	}
	
	
	@RequestMapping(value = "/board/boardWrite.do")
	public String boardWrite() {
		
		return "/board/boardWrite";
	}
			
	
	@RequestMapping(value = "/board/boardWriteAction.do")
	public String boardWriteAction(
			@RequestParam("title") String title,
			@RequestParam("content") String content,
			@RequestParam("writer") String writer,
			@RequestParam("pwd") String pwd
			) {		
//		String ip= null;
//		try {
//			ip = InetAddress.getLocalHost().getHostAddress();
//		} catch (UnknownHostException e) {			
//			e.printStackTrace();
//		}
//		int midx = 1;
//		Date date_now = new Date(System.currentTimeMillis());
//		SimpleDateFormat fm = new SimpleDateFormat("yy-MM-dd HH:mm");
//		Date to=fm.parse(date);
//		String to2=fm.format(to);
		
		int result = bs.boardInsert(title, content, writer, pwd);
				
		return "redirect:/board/boardList.do";
	}
	
	@RequestMapping(value="/board/boardModify.do")
	public String boardModify(
			@RequestParam("bidx") int bidx, 
			Model model) {
		
		//boardService�� �ִ� �޼ҵ� ȣ��
		BoardVo bv = bs.boardSelectOne(bidx);
		model.addAttribute("bv", bv);		
		
		return "board/boardModify";
	}
	
	@RequestMapping(value="/board/boardModifyAction.do")
	public String boardModifyAction(
			@RequestParam("bidx") int bidx,
			@RequestParam("title") String title,
			@RequestParam("content") String content,
			@RequestParam("writer") String writer,
			@RequestParam("pwd") String pwd
			) {
		
		int value = bs.boardModify(bidx, title, content, writer, pwd);
		
		return "redirect:/board/boardContents.do?bidx="+bidx;	
	}
	
	@RequestMapping(value="/board/boardDelete.do")
	public String boardDelete(
			@ModelAttribute("bidx") int bidx,Model model) {
		
		BoardVo bv = bs.boardSelectOne(bidx);
		model.addAttribute("bv", bv);		
		
		return "board/boardDeleteAction.do";
	}
	
	@RequestMapping(value="/board/boardDeleteAction.do")
	public String boardDeleteAction(
			@RequestParam("bidx") int bidx
			) {
		
		int value = bs.boardDelete(bidx);		
		
		return "redirect:/board/boardList.do";
	}
	
	@RequestMapping(value = "/board/boardTopList.do")
	public String boardTopList() {
		
		ArrayList<BoardVo> alist =  bs.boardTopList();
		System.out.println("alist����"+alist);
		for (BoardVo bv : alist){
//			System.out.println(bv.getRating());
		}
		return "redirect:/";		
	}
	
	
	
	
	
}
