package com.ezen.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ezen.myapp.domain.BoardVo;
import com.ezen.myapp.domain.NoteVo;
import com.ezen.myapp.service.NoteService;

@Controller
public class NoteController {
	
	@Autowired
	NoteService ns;
	
	@RequestMapping(value="/noteSend.do")
    public String noteSend(
			@RequestParam("send_nick") String send_nick,
			@RequestParam("recv_nick") String recv_nick,
			@RequestParam("content") String content,
			HttpSession session
			){

		send_nick = (String)session.getAttribute("membernickname");
        int result=ns.noteSend(send_nick, recv_nick, content);

        return "redirect:/noteListSend.do";
    }
	
	@RequestMapping(value="/noteListRecv.do")
    public String noteListRecv(
    		NoteVo nv, Model model, HttpSession session
    		){
		String recv_nick = (String)session.getAttribute("membernickname");
		ArrayList<NoteVo> alist = 	ns.noteListRecv(recv_nick);
        model.addAttribute("alist", alist);

        return "noteListRecv";
    }
	
	@RequestMapping(value="/noteListSend.do")
    public String noteListSend(
    		NoteVo nv, Model model, HttpSession session
    		){
		String send_nick = (String)session.getAttribute("membernickname");
		ArrayList<NoteVo> alist = 	ns.noteListSend(send_nick);
        model.addAttribute("alist", alist);

        return "noteListSend";
    }
	
	@RequestMapping(value = "/noteSendPage.do")
	public String noteSendPage() {
		
		
		
		return "noteSendPage";
	}
	
	@RequestMapping(value="/{no}/noteDelete.do")
	public String noteDelete(
			@PathVariable("no") int no
			) {
							
		int value = ns.noteDelete(no);
		
		return "noteListRecv";
	}
	
}
