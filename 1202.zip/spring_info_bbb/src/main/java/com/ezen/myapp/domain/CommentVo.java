package com.ezen.myapp.domain;


public class CommentVo {
	
	private int cidx;
	private String c_contents;
	private String writeday;
	private String ip;
	private int bidx;
	private int midx;
	private String cdelyn;
	private String membernickname;
	
	public String getMembernickname() {
		return membernickname;
	}
	public void setMembernickname(String membernickname) {
		this.membernickname = membernickname;
	}
	public int getCidx() {
		return cidx;
	}
	public void setCidx(int cidx) {
		this.cidx = cidx;
	}
	public String getC_contents() {
		return c_contents;
	}
	public void setC_contents(String c_contents) {
		this.c_contents = c_contents;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public int getBidx() {
		return bidx;
	}
	public void setBidx(int bidx) {
		this.bidx = bidx;
	}
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getCdelyn() {
		return cdelyn;
	}
	public void setCdelyn(String cdelyn) {
		this.cdelyn = cdelyn;
	}
	
	
	

}
