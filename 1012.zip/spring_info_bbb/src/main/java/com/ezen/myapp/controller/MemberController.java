package com.ezen.myapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ezen.myapp.domain.MemberVo;
import com.ezen.myapp.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService ms;
	
	
	@RequestMapping(value="/memberLogin.do")
	public String memberLogin() {				
		
		return "memberLogin";
	}
	
	
	@RequestMapping(value="/member/memberLoginAction.do")
	public String memberLoginAction(
			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			Model model) {
		
		MemberVo mv = ms.memberLogin(memberid, memberpwd);
	//	System.out.println("id:"+mv.getMemberid());
				
		String path =null;
		if (mv == null) {
			path = "redirect:/memberLogin.do";
		}else {
			model.addAttribute("memberid", mv.getMemberid());
			
		//	HttpSession session = request.getSession();
		//	session.setAttribute("id", mv.getMemberid());
			path ="redirect:/boardList.do";
		}
		return path;
	}
	
	@RequestMapping(value="/memberJoin.do")
	public String memberJoin() {				
		
		return "memberJoin";
	}
	
	@RequestMapping(value="/member/memberJoinAction.do")
	public String memberJoinAction(

			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			@RequestParam("membername") String membername,
			@RequestParam("membernickname") String membernickname,
			@RequestParam("membergender") String membergender,
			@RequestParam("memberbirth") int memberbirth,
			@RequestParam("memberemail") String memberemail,
			@RequestParam("memberphone") int memberphone,
			@RequestParam("membermbti") String membermbti,
			@RequestParam("memberaddr") String memberaddr
			) {
				
		int result =ms.memberInsert(memberid, memberpwd, membername, membernickname, membergender, memberbirth, memberemail, memberphone, membermbti, memberaddr);
		return "redirect:/memberLogin.do";
	}
	@RequestMapping(value="/memberProfile.do")
	public String memberProfile(			
			@RequestParam("midx") int midx, Model model
			) {
		MemberVo mv = ms.memberSelectOne(midx);
		model.addAttribute("mv", mv);		

		return "memberProfile";
	}
	
}
