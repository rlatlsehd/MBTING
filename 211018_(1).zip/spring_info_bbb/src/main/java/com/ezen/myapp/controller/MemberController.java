package com.ezen.myapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ezen.myapp.domain.MemberVo;
import com.ezen.myapp.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService ms;
	
	
	@RequestMapping(value="/memberLogin.do")
	public String memberLogin() {				
		
		return "memberLogin";
	}
	
	
	@RequestMapping(value="/member/memberLoginAction.do")
	public String memberLoginAction(
			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			Model model, HttpServletRequest request) {
		
		MemberVo mv = ms.memberLogin(memberid, memberpwd);
		System.out.println("midx:"+mv.getMidx());
				
		String path =null;
		if (mv == null) {
			path = "redirect:/memberLogin.do";
		}else {
			model.addAttribute("memberid", mv.getMemberid());
			
			HttpSession session = request.getSession();
			session.setAttribute("memberid", mv.getMemberid());
			session.setAttribute("midx", mv.getMidx());
			path ="redirect:/index2.do";
		}
		return path;
	}
	
	@RequestMapping(value="/memberJoin.do")
	public String memberJoin() {				
		
		return "memberJoin";
	}
	
	@RequestMapping(value="/member/memberJoinAction.do")
	public String memberJoinAction(

			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			@RequestParam("membername") String membername,
			@RequestParam("membernickname") String membernickname,
			@RequestParam("membergender") String membergender,
			@RequestParam("memberbirth") int memberbirth,
			@RequestParam("memberemail") String memberemail,
			@RequestParam("memberphone") int memberphone,
			@RequestParam("membermbti") String membermbti,
			@RequestParam("memberaddr") String memberaddr,
			@RequestParam("aggrement") String aggrement
			) {
				
		int result =ms.memberInsert(memberid, memberpwd, membername, membernickname, membergender, memberbirth, memberemail, memberphone, membermbti, memberaddr, aggrement);
		
		return "redirect:/memberLogin.do";
	}
	@RequestMapping(value="/memberFindId.do")
	public String memberFindId() {				
		
		return "memberFindId";
	}
	@RequestMapping(value="/member/memberFindIdAction.do")
	public String memberFindIdAction(
			@RequestParam("membername") String membername,
			@RequestParam("memberemail") String memberemail,
			Model model) 
	{
	MemberVo mv = ms.memberFindId(membername, memberemail);
	System.out.println("ms"+ms);
	System.out.println("�ɹ����̵�"+mv.getMemberid());
	model.addAttribute("mv", mv);
	
		return "memberFindId2";
	}@RequestMapping(value="/memberFindId2.do")
	public String memberFindId2() {				
		
		return "memberFindId2";
	}
	@RequestMapping(value="/memberFindPwd.do")
	public String memberFidPwd() {				
		
		return "memberFindPwd";
	}
	@RequestMapping(value="/memberProfile.do")
	public String memberProfile(			
			Model model, HttpSession session
 			) {
		int midx = (int)session.getAttribute("midx");
		MemberVo mv = ms.memberSelectOne(midx);
		model.addAttribute("mv", mv);		

		return "memberProfile";
	}
	@RequestMapping(value="/memberLogout.do")
	public String memberLogout(			
			Model model, HttpServletRequest request
 			) {
		HttpSession session = request.getSession();
		session.invalidate();
				

		return "redirect:/index.do";
	}
	
}
