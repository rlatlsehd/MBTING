package com.ezen.myapp.persistence;

import java.util.ArrayList;
import java.util.HashMap;


import com.ezen.myapp.domain.NoteVo;


public interface NoteService_Mapper {
	
	//���̹�Ƽ���� ����� �޼ҵ带 �����Ѵ�
	
	public int noteSend(HashMap<String,Object> hm);
	
	public ArrayList<NoteVo> noteListRecv(String recv_nick);
	
	public ArrayList<NoteVo> noteListSend(String send_nick);







	



}
