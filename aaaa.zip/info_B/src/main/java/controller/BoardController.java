package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import domain.Criteria;
import domain.PageMaker;
import domain.SearchCriteria;
import service.BoardDao;
import service.BoardVo;
import service.CommentDao;
import service.CommentVo;



@WebServlet("/BoardController")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//���ε� ���� ���
	String uploadPath ="D:\\dev_html\\info_B\\src\\main\\webapp\\image\\";
	//����Ǵ� ����
	String savedPath = "filefolder";
	//����� �� ���
	String saveFullPath = uploadPath+ savedPath;
	//����뷮
	int sizeLimit =1024*1024*15;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response, String str) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		response.setContentType("text/html; charset=UTF-8");

		if(str.equals("boardList.do")) { 			// Dao ��ü ���� �� Dao ��ü �ȿ� �޼ҵ带 ȣ���Ͽ� ������ �����͸� ��´�. 
			String searchType= request.getParameter("searchType");
			if(searchType == null) searchType="subject";
			String keyword= request.getParameter("keyword");
			if(keyword == null) keyword="";
			
			//����¡ó��
			String page = request.getParameter("page");
			if(page==null) page="1";			
			int page2 = Integer.parseInt(page);
		
			SearchCriteria scri = new SearchCriteria();
			scri.setPage(page2);
			scri.setKeyword(keyword);
			scri.setSearchType(searchType);
			
			
			PageMaker pm = new PageMaker();
			pm.setScri(scri);
			
			
			BoardDao bd= new BoardDao(); 
			ArrayList<BoardVo> alist = bd.boardSelectAll(scri);
			
			int value = bd.boardTotalCount(scri);
			
			//��� ���� ǥ��
			 String bidx = request.getParameter("bidx");
	         int bidx2 = Integer.parseInt(bidx);
             
	         CommentDao cd = new CommentDao();
	         int value2 = cd.commentCount(bidx2);
	         CommentVo cv = new CommentVo();
	         
	         
	        cv.setCommentcount(value2);
				
			request.setAttribute("cv", cv);
			
			
			//��ü ������ �������� ������ �������Ѵ�
			pm.setTotalCount(value);
			request.setAttribute("alist", alist);
			request.setAttribute("pm", pm);
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardList.jsp"); // ���帮��Ʈ �������� �̵�
			rd.forward(request, response);
		}else if(str.equals("boardWriteAction.do")) {
			
			
			//�̹����� ���Ҿ� ���ڿ��� multipartRequest Ŭ������ �ѱ��
			MultipartRequest multi = new MultipartRequest(request, saveFullPath, sizeLimit, "UTF-8", new DefaultFileRenamePolicy());
			
			//�����ڿ� ����� ������ ���� ��ü�� �����Ѵ�
			Enumeration files = multi.getFileNames();			
			//�����ڿ� ���� ������ ���� ���� ������
			String file = (String)files.nextElement();
			//����Ǵ� ���� �̸�
			String fileName = multi.getFilesystemName(file);
			//���� ���� �̸�
			String originFileName = multi.getOriginalFileName(fileName);
			
			
			String subject= multi.getParameter("subject");
			String contents= multi.getParameter("contents");
			String writer= multi.getParameter("writer");
			String pwd = multi.getParameter("pwd");
			String ip = InetAddress.getLocalHost().getHostAddress();
			
			HttpSession session = request.getSession();
			int midx = (int)session.getAttribute("midx");
			
			BoardDao bd = new BoardDao();
			int value=bd.boardInsert(subject, contents, writer,pwd,ip,midx, fileName);
			
			if(value==1) {
				response.sendRedirect(request.getContextPath()+"/board/boardList.do");
			}else {
				response.sendRedirect(request.getContextPath()+"/board/boardWrite.do");
			}
		}else if(str.equals("boardWrite.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardWrite.jsp");
			rd.forward(request, response);
		}else if(str.equals("boardContents.do")) {
			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			
			BoardDao bd = new BoardDao();
			BoardVo bv = bd.boardSelectOne(bidx2);
			request.setAttribute("bv", bv);
		
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardContents.jsp");
			rd.forward(request, response);
		}else if(str.equals("boardModify.do")) {
			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			BoardDao bd = new BoardDao();
			BoardVo bv = bd.boardSelectOne(bidx2);
			request.setAttribute("bv", bv);
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardModify.jsp");
			rd.forward(request, response);
		}else if(str.equals("boardModifyAction.do")){
			System.out.println("�������γѾ�Դ���");
			
			String subject= request.getParameter("subject");
			String contents= request.getParameter("contents");
			String writer= request.getParameter("writer");
			String pwd= request.getParameter("pwd");

			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			//ó���ϴ� �޼ҵ�  ȣ���ϱ�
			BoardDao bd = new BoardDao();
			int value=bd.boardModify(subject, contents, writer,pwd, bidx2);
			
			if(value==1) {
				response.sendRedirect(request.getContextPath()+"/board/boardContents.do?bidx="+bidx);
			}else {
				response.sendRedirect(request.getContextPath()+"/board/boardModify.do?bidx="+bidx);
			}
		}else if(str.equals("boardDelete.do")) {
			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			BoardDao bd = new BoardDao();
			BoardVo bv = bd.boardSelectOne(bidx2);
			request.setAttribute("bv", bv);
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardDelete.jsp");
			rd.forward(request, response);
		}else if(str.equals("boardDeleteAction.do")) {
			String pwd = request.getParameter("pwd");
			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			
			//ó��
			BoardDao bd = new BoardDao();
			int value = bd.boardDelete(bidx2, pwd);
			
			
			if(value==1) {
				response.sendRedirect(request.getContextPath()+"/board/boardList.do");
			}else {
				response.sendRedirect(request.getContextPath()+"/board/boardDelete.do?bidx="+bidx);
			}
		}else if(str.equals("boardReply.do")) {
			String bidx = request.getParameter("bidx");
			String originbidx = request.getParameter("originbidx");
			String depth= request.getParameter("depth");
			String nlevel = request.getParameter("nlevel");
			
			
			BoardVo bv= new BoardVo();
			bv.setBidx(Integer.parseInt(bidx));
			bv.setOriginbidx(Integer.parseInt(originbidx));
			bv.setDepth(Integer.parseInt(depth));
			bv.setNlevel(Integer.parseInt(nlevel));
			
			request.setAttribute("bv", bv);
			
			RequestDispatcher rd = request.getRequestDispatcher("/boardReply.jsp");
			rd.forward(request, response);
			
		}else if(str.equals("boardReplyAction.do")) {
			String bidx= request.getParameter("bidx");
			String originbidx= request.getParameter("originbidx");
			String depth= request.getParameter("depth");
			String nlevel = request.getParameter("nlevel");
			String subject= request.getParameter("subject");
			String contents= request.getParameter("contents");
			String writer= request.getParameter("writer");
			String pwd = request.getParameter("pwd");
	
			//ó���κ�
			BoardVo bv= new BoardVo();
			bv.setBidx(Integer.parseInt(bidx));
			bv.setOriginbidx(Integer.parseInt(originbidx));
			bv.setDepth(Integer.parseInt(depth));
			bv.setNlevel(Integer.parseInt(nlevel));
			bv.setSubject(subject);
			bv.setContents(contents);
			bv.setWriter(writer);
			bv.setPwd(pwd);
			
			String ip = InetAddress.getLocalHost().getHostAddress();
			bv.setIp(ip);
			HttpSession session = request.getSession();
			int midx = (int)session.getAttribute("midx");
			bv.setMidx(midx);
			
			//boardReply(bv)
			BoardDao bd = new BoardDao();
			int value=bd.boardReply(bv);
			
			
			response.sendRedirect(request.getContextPath()+"/board/boardList.do");			
			
			
			
			
		}else if(str.equals("fileDownload.do")) {
			String fileName = request.getParameter("fileName");
			String filePath = saveFullPath + File.separator + fileName;
			
			//�ش���ġ�� �����ϴ� ������ �о� ���δ�
			FileInputStream fileInputStream = new FileInputStream(filePath);
			
		//	String mimeType = getServletContext().getMimeType(filePath);
			Path source = Paths.get(filePath);
			String mimeType = Files.probeContentType(source);
			
			if(mimeType == null) {
				mimeType = "application/octet-stream";
			}
			response.setContentType(mimeType);
			
			String encoding = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
			response.setHeader("Content-Disposition", "attachment;FileName="+encoding);
			
			//���Ͼ���
			ServletOutputStream servletOutStream = response.getOutputStream(); 
			
			byte[] b = new byte[4096];
			int read = 0;
			
			// �о���� ������ 4����Ʈ Ÿ������ ������ ����
			while((read = fileInputStream.read(b, 0, b.length)) != -1) {
				servletOutStream.write(b, 0, read);
			}
			servletOutStream.flush();
			servletOutStream.close();
			fileInputStream.close();
		}else if (str.equals("comments.do")) {
			System.out.println("�Ѿ�Դ���");
			String bidx = request.getParameter("bidx");
			int bidx2 =Integer.parseInt(bidx);
			String midx = request.getParameter("midx");
			int midx2 =Integer.parseInt(midx);
			String c_writer= request.getParameter("c_writer");
			String c_subject = request.getParameter("c_subject");
			String c_contents = request.getParameter("c_contents");
			
//			System.out.println(bidx+midx+c_writer+c_subject +c_contents);
			
			CommentDao cd = new CommentDao();
			int value = cd.commnetInsert(bidx2, midx2, c_subject, c_contents, c_writer);
			System.out.println(value);
			
			//		String str2 = "{\"test\":\"1\"}";
			
			JSONObject jo = new JSONObject();
			jo.put("result", value);
			
			
			PrintWriter out =response.getWriter();
			out.println(jo.toString());
		}else if (str.equals("commentsAll.do")) {
			String bidx = request.getParameter("bidx");
			int bidx2 = Integer.parseInt(bidx);
			System.out.println("bidx:"+bidx);
		
			
			CommentDao cd= new CommentDao(); 
			ArrayList<CommentVo> alist = cd.commentSelectAll(bidx2);
			

			JSONArray ja = new JSONArray();
			
			
			for(CommentVo cv : alist) {
				JSONObject jo = new JSONObject();
				jo.put("c_contents", cv.getC_contents());
				jo.put("c_subject", cv.getC_subject());
				jo.put("c_writer", cv.getC_writer());
				jo.put("cidx", cv.getCidx());
				ja.add(jo);
	
			}
			PrintWriter out =response.getWriter();
			out.println(ja.toString());
	
			
		}else if(str.equals("commentDelete.do")) {
			String cidx = request.getParameter("cidx");
			int cidx2 = Integer.parseInt(cidx);
			
			CommentDao cd = new CommentDao();
			int value = cd.commentDelete(cidx2);
			
			
			JSONObject jo = new JSONObject();
			jo.put("result", value);
			
			PrintWriter out =response.getWriter();
			out.println(jo.toString());
			
		}else if(str.equals("commentMore.do")) {
			 String bidx = request.getParameter("bidx");
	         int bidx2 = Integer.parseInt(bidx);
	         String page = request.getParameter("page");
	         if (page == null) page = "1";
	         int page2=  Integer.parseInt(page);
	         int nextpage= 0;
			
	         JSONArray ja = new JSONArray();
             
	         CommentDao cd = new CommentDao();
	         int commentTotalCount = (int)cd.commentTotalCount(bidx2);
	         System.out.println("commentTotalCount:"+commentTotalCount);
	         if (page2 < commentTotalCount) {
	            nextpage = page2 +1;
	         }else {
	            nextpage = 9999;
	         }	         
	         ArrayList<CommentVo> alist =  cd.commentMore(bidx2, page2);	         
	              
	         for(CommentVo cv : alist) {   
	         JSONObject  jo = new JSONObject();
	         jo.put("c_contents", cv.getC_contents());
	         jo.put("c_subject", cv.getC_subject());
	         jo.put("c_writer", cv.getC_writer());
	         jo.put("cidx", cv.getCidx());         
	         ja.add(jo);         
	         }         
	         
	         HashMap<String,Object> hm = new HashMap<String,Object>();
	         hm.put("ja", ja);
	         hm.put("nextpage", nextpage);
	         
	         JSONObject jo2 = new JSONObject(hm);	         
	         
	         PrintWriter out = response.getWriter();
	         out.println(jo2);   

		}
	
	}
	
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
