package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbcon.Dbconn;
import domain.Criteria;
import domain.SearchCriteria;

public class CommentDao {
	private Connection conn; //��������
	private PreparedStatement pstmt; //��������
	
	public CommentDao(){
		Dbconn conn = new Dbconn();
		this.conn = conn.getConnect();
	}
	
	public int commnetInsert(int bidx, int midx, String c_subject, String c_contents, String c_writer){
		int value=0;	
		try{
		String sql = "insert into bclass_comment"+"(cidx,c_subject, c_contents, c_writer, bidx,midx)"+" values(cidx_seq.nextval,?,?,?,?,?)";
	
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,c_subject);
		pstmt.setString(2,c_contents);
		pstmt.setString(3,c_writer);
		pstmt.setInt(4, bidx);
		pstmt.setInt(5, midx);
		value = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		pstmt.close();
		conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		return value;
	}
	
	public ArrayList<CommentVo> commentSelectAll(int bidx) {
		//ArrayList Ŭ���� ����
		ArrayList<CommentVo> alist = new ArrayList<CommentVo>(); 
		ResultSet rs=null;
		//String sql = "select * from bclass_comment where bidx=? and delYN='N' order by cidx";
		String sql = "select B.rnum,B.* from "
				+"(select rownum as rnum, A.* from "
				+"(select * from bclass_comment where delyn='N' and bidx=? "
				+"order by cidx) A " 
				+"where rownum <= ?) B where rnum >=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bidx);
			pstmt.setInt(2, 15);
			pstmt.setInt(3, 1);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
			
				CommentVo cv = new CommentVo();
				
				cv.setCidx(rs.getInt("cidx"));
				cv.setC_subject(rs.getString("c_subject"));
				cv.setC_contents(rs.getString("c_contents"));
				cv.setC_writer(rs.getString("c_writer"));				
				alist.add(cv);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return alist;
	}
	
	public int commentDelete(int cidx){
		int value=0;
		String sql = "update bclass_comment set delYn = 'Y' where cidx=?";
		
		try{
		//����ȭ
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1,cidx);
		value = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}
		return value;
	}
	public ArrayList<CommentVo> commentMore(int bidx, int page) {
		ArrayList<CommentVo> alist = new ArrayList<CommentVo>();		
		ResultSet rs = null;		
		int cnt= 0;

		String sql ="select B.rnum,B.* from  "
				+ "(select rownum as rnum, A.* from "
				+ "(select * from bclass_comment  where delyn='N' and bidx=?"
				+ "order by cidx) A  "
				+ "where rownum <= ?) B "
				+ "where B.rnum >=? ";				
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bidx);	
			pstmt.setInt(2, 15*page);	
			pstmt.setInt(3, 1);	
			rs =  pstmt.executeQuery();
						
			while(rs.next()) {
				CommentVo cv = new CommentVo();
				cv.setCidx(rs.getInt("cidx"));
				cv.setC_contents(rs.getString("c_contents"));
				cv.setC_subject(rs.getString("c_subject"));
				cv.setC_writer(rs.getString("c_writer"));
				alist.add(cv);
			}		
			
		} catch (SQLException e) {	
			e.printStackTrace();
		}		
	
		return alist;
	}
	public int commentTotalCount(int bidx) {
		int value=0;
		ResultSet rs = null;
		
		String sql = "select count(*) as cnt from bclass_comment "
				+"where delyn = 'N' and bidx=? ";
		
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bidx);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				value = rs.getInt("cnt");
				System.out.println("bidx�� ��ġ�ϴ� �Խù��� ��� ���� = "+value);
				value = (int)Math.ceil(value/15.0);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("�� ��� ������ ������ �� ="+value);
		return value;
	}
	public int commentCount(int bidx) {
		int value=0;
		ResultSet rs = null;
		
		String sql = "select count(*) as cnt from bclass_comment "
				+"where delyn = 'N' and bidx=? ";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bidx);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				value = rs.getInt("cnt");
				System.out.println("bidx�� ��ġ�ϴ� �Խù��� ��� ���� = "+value);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return value;
	}
}
