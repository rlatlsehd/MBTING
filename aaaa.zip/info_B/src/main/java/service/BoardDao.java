package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbcon.Dbconn;
import domain.Criteria;
import domain.SearchCriteria;

public class BoardDao {
	private Connection conn; //��������
	private PreparedStatement pstmt; //��������
	
	public BoardDao(){
		Dbconn conn = new Dbconn();
		this.conn = conn.getConnect();
	}
	public ArrayList<BoardVo> boardSelectAll(SearchCriteria scri) {
		//ArrayList Ŭ���� ����
		ArrayList<BoardVo> alist = new ArrayList<BoardVo>(); 
		ResultSet rs=null;
		//String sql = "select * from bclass_board where delYn='N' order by originbidx desc, depth";
		//�Ǽ��Ѱ� sql�� +�� ���� ���� �� ���� ����
		String str=null;
		if(scri.getSearchType().equals("subject")) {
			str = "and subject like ? ";				
		}else if (scri.getSearchType().equals("writer")) {
			str = "and writer like ? ";	
		}else if(scri.getSearchType().equals("contents")) {
			str = "and contents like ? ";	
		}
		String sql = "select B.rnum,B.* from "
				+"(select rownum as rnum, A.* from "
				+"(select * from bclass_board where delyn='N' "
				+ str
				+"order by originbidx desc, depth) A " 
				+"where rownum <= ?) B where rnum >=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+scri.getKeyword()+"%");
			pstmt.setInt(2, scri.getPerPageNum()*scri.getPage());
			pstmt.setInt(3, (scri.getPage()-1)*scri.getPerPageNum()+1);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				//rs�� ��� ���� ���پ� BoardVo�� ��´�.
				BoardVo bv = new BoardVo();
				//�۹�ȣ ���� �ۼ��� ��ȸ�� ��¥
				bv.setBidx(rs.getInt("bidx"));
				bv.setSubject(rs.getString("subject"));
				bv.setWriter(rs.getString("writer"));
				bv.setViewcount(rs.getInt("viewcount"));
				bv.setWriteday(rs.getString("writeday"));
				bv.setNlevel(rs.getInt("nlevel"));
				alist.add(bv);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return alist;
	}
	
	public int boardInsert(String subject, String contents, String writer, String pwd, String ip,int midx, String fileName){
		int k=0;	
		try{
		String sql = "insert into bclass_board"+"(bidx,originbidx,depth,nlevel,subject, contents, writer,viewcount,ip,pwd,midx, fileName)"+" values(bidx_seq.nextval,bidx_seq.nextval,0,0,?,?,?,0,?,?,?,?)";
	
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,subject);
		pstmt.setString(2,contents);
		pstmt.setString(3,writer);
		pstmt.setString(4, ip);
		pstmt.setString(5,pwd);
		pstmt.setInt(6, midx);
		pstmt.setString(7,fileName);
		k = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		pstmt.close();
		conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		return k;
	}
	
public BoardVo boardSelectOne(int bidx) {
		
		ResultSet rs = null;
		BoardVo bv = null;
		String sql = "select * from bclass_board where delYn='N' and bidx =?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bidx);
			rs = pstmt.executeQuery();		
			if(rs.next()) {
				bv = new BoardVo();
				//String subject= rs.getString("subject");
				//String contents= rs.getString("contents");
				//String writer= rs.getString("writer");
				bv.setSubject(rs.getString("subject"));
				bv.setContents(rs.getString("contents"));
				bv.setWriter(rs.getString("writer"));
				
				bv.setBidx(rs.getInt("bidx"));
				bv.setOriginbidx(rs.getInt("originbidx"));
				bv.setDepth(rs.getInt("depth"));
				bv.setNlevel(rs.getInt("nlevel"));
				bv.setFilename(rs.getString("filename"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return bv;
	}
	public int boardModify(String subject, String contents, String writer, String pwd, int bidx){
		int value=0;
		String sql = "update bclass_board set subject=?, contents=?, writer=?, writeday=sysdate where pwd=? and bidx=?";
		try{
		//����ȭ
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,subject);
		pstmt.setString(2,contents);
		pstmt.setString(3,writer);
		pstmt.setString(4,pwd);
		pstmt.setInt(5, bidx);
		value = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		pstmt.close();
		conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		return value;
	}
	public int boardDelete(int bidx, String pwd){
		int value=0;
		String sql = "update bclass_board set delYn = 'Y' , writeday=sysdate where bidx=? and pwd=?";
		
		try{
		//����ȭ
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1,bidx);
		pstmt.setString(2,pwd);
		value = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		pstmt.close();
		conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		return value;
	}
	
	public int boardReply(BoardVo bv) {
		int value = 0;
		int value2 = 0;
		int value3 = 0;
		
		String sql= "insert into bclass_board"
				+"(bidx,originbidx,depth,nlevel,subject, contents, writer,viewcount,ip,pwd,midx)"
				+" values(bidx_seq.nextval,?,?,?,?,?,?,0,?,?,?) ";
		String sql2 = "update bclass_board set depth=depth+1 where originbidx=? and depth>?";
		
		try {
			conn.setAutoCommit(false);
			
			pstmt= conn.prepareStatement(sql2);
			pstmt.setInt(1, bv.getOriginbidx());
			pstmt.setInt(2, bv.getDepth());
			value = pstmt.executeUpdate();
			
			pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1,bv.getOriginbidx());
			pstmt.setInt(2,bv.getDepth()+1);
			pstmt.setInt(3,bv.getNlevel()+1);
			pstmt.setString(4, bv.getSubject());
			pstmt.setString(5,bv.getContents());
			pstmt.setString(6, bv.getWriter());
			pstmt.setString(7, bv.getIp());
			pstmt.setString(8,bv.getPwd());
			pstmt.setInt(9, bv.getMidx());
			value2 = pstmt.executeUpdate();
			
			conn.commit();
			value3 = value+value2;
	
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return value3;
	}
	
	
	public int boardTotalCount(SearchCriteria scri) {
		int value=0;
		ResultSet rs = null;
		String str=null;
		
		if(scri.getSearchType().equals("subject")) {
			str = "and subject like ?  ";
		}else if(scri.getSearchType().equals("writer")) {
			str = "and writer like ?  ";
		}else if(scri.getSearchType().equals("contents")) {
			str = "and contents like ? ";	
		}
		String sql = "select count(*) as cnt from bclass_board "
				+"where delyn = 'N' "
				+ str ;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+scri.getKeyword()+"%");
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				value = rs.getInt("cnt");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return value;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
