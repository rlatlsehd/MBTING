package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbcon.Dbconn;

public class MemberDao {
	
	private Connection conn; //��������
	private PreparedStatement pstmt; //��������
	
	public MemberDao(){
		Dbconn conn = new Dbconn();
		this.conn = conn.getConnect();
	}
	
	
	public int memberInsert(String memberid, String memberpwd, String membername, String membergender, long memberjumin2, String memberaddr, long memberphone2, String tot_memberhobby, String ip, String to_date, String memberemail){
		int k=0;
		
		
		try{
		
		String sql = "insert into bclass_member2(MIDX, MEMBERID, MEMBERPWD, MEMBERNAME, MEMBERGENDER, MEMBERJUMIN, MEMBERADDR, MEMBERPHONE, MEMBERHOBBY, IP, writeday, memberemail) values(midx_seq.nextval,?,?,?,?,?,?,?,?,?,?,?)";
	
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,memberid);
		pstmt.setString(2,memberpwd);
		pstmt.setString(3,membername);
		pstmt.setString(4,membergender);
		pstmt.setLong(5,memberjumin2);
		pstmt.setString(6,memberaddr);
		pstmt.setLong(7,memberphone2);
		pstmt.setString(8,tot_memberhobby);
		pstmt.setString(9, ip);
		pstmt.setString(10, to_date);
		pstmt.setString(11, memberemail);
		k = pstmt.executeUpdate();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		pstmt.close();
		conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
		return k;
	}
	
	public ArrayList<MemberVo> selectMemberAll() {
		//ArrayList Ŭ���� ����
		ArrayList<MemberVo> alist = new ArrayList<MemberVo>(); 
		
		String sql = "select * from bclass_member2 order by midx desc";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				//rs�� ��� ���� ���پ� MemberVo�� ��´�.
				MemberVo mv = new MemberVo();
				mv.setMidx(rs.getInt("midx"));
				mv.setMembername(rs.getString("membername"));
				mv.setWriteday(rs.getString("writeday"));
				alist.add(mv);
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return alist;
	}
	
	
	public MemberVo memberLogin(String memberid, String memberpwd) {
		
		String sql = "select *  from bclass_member2 where memberid =? and memberpwd = ?";
		//int value=0;
		ResultSet rs=null;
		MemberVo mv =null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberid);
			pstmt.setString(2, memberpwd);
			rs =pstmt.executeQuery();
			
			if(rs.next()) {
				mv = new MemberVo();
				mv.setMidx(rs.getInt("midx"));
				mv.setMembername(rs.getString("membername"));
				mv.setMemberid(rs.getString("memberid"));
				//value = rs.getInt("cnt");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mv;
	}
	
	
	public MemberVo selectOne(int midx) {
		
		ResultSet rs = null;
		MemberVo mv = null;
		String sql = "select memberid, memberjumin, memberhobby, membername, memberphone from bclass_member2 where midx =?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, midx);
			rs = pstmt.executeQuery();		
			if(rs.next()) {
				mv = new MemberVo();
				
				String memberid= rs.getString("memberid");
				mv.setMemberid(memberid);
				long memberjumin= rs.getLong("memberjumin");
				mv.setMemberjumin(memberjumin);
				String memberhobby = rs.getString("memberhobby");
				mv.setMemberhobby(memberhobby);
				String membername = rs.getString("membername");
				mv.setMembername(membername);
				long memberphone = rs.getLong("memberphone");
				mv.setMemberphone(memberphone);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mv;
	}
	
	
	
	
	
	
	
	
}
