package service;

public class MemberVo { //value object ���� ��� ��ü
	
	private int midx;
	private String memberid;
	private String memberpwd;
	private String membername;
	private String membergender;
	private long memberjumin;
	private String memberaddr;
	private long memberphone;
	private String memberhobby;
	private String writeday;
	private String ip;
	private String delyn;
	private String memberemail;
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMemberpwd() {
		return memberpwd;
	}
	public void setMemberpwd(String memberpwd) {
		this.memberpwd = memberpwd;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembergender() {
		return membergender;
	}
	public void setMembergender(String membergender) {
		this.membergender = membergender;
	}
	public long getMemberjumin() {
		return memberjumin;
	}
	public void setMemberjumin(long memberjumin) {
		this.memberjumin = memberjumin;
	}
	public String getMemberaddr() {
		return memberaddr;
	}
	public void setMemberaddr(String memberaddr) {
		this.memberaddr = memberaddr;
	}
	public long getMemberphone() {
		return memberphone;
	}
	public void setMemberphone(long memberphone) {
		this.memberphone = memberphone;
	}
	public String getMemberhobby() {
		return memberhobby;
	}
	public void setMemberhobby(String memberhobby) {
		this.memberhobby = memberhobby;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getDelyn() {
		return delyn;
	}
	public void setDelyn(String delyn) {
		this.delyn = delyn;
	}
	public String getMemberemail() {
		return memberemail;
	}
	public void setMemberemail(String memberemail) {
		this.memberemail = memberemail;
	}
	
	
	
}
