package com.ezen.myapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ezen.myapp.domain.MemberVo;
import com.ezen.myapp.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService ms;
	
	//�α���
	@RequestMapping(value="/memberLogin.do")
	public String memberLogin() {				
		
		return "memberLogin";
	}
	
	
	@RequestMapping(value="/member/memberLoginAction.do")
	public String memberLoginAction(
			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
		 HttpServletRequest request, RedirectAttributes rttr) {
		
		MemberVo mv = ms.memberLogin(memberid, memberpwd);
		System.out.println("mv:"+mv);
				
		String path =null;
		
		
		if (mv == null) {
			rttr.addFlashAttribute("msg", "�α��� ������ ���� �ʽ��ϴ�.");
			path = "redirect:/memberLogin.do";
		}else{
			//model.addAttribute("memberid", mv.getMemberid());
			rttr.addAttribute("memberid", mv.getMemberid());
			HttpSession session = request.getSession();
			session.setAttribute("memberid", mv.getMemberid());
			session.setAttribute("midx", mv.getMidx());
			session.setAttribute("membernickname", mv.getMembernickname());
			session.setAttribute("membermbti", mv.getMembermbti());
			
			path ="redirect:/index2.do";
		}
		
		return path;
	}
	//ȸ������
	@RequestMapping(value="/memberJoin.do")
	public String memberJoin() {				
		
		return "memberJoin";
	}
	
	@RequestMapping(value="/member/memberJoinAction.do")
	public String memberJoinAction(

			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			@RequestParam("membername") String membername,
			@RequestParam("membernickname") String membernickname,
			@RequestParam("membergender") String membergender,
			@RequestParam("memberbirth") int memberbirth,
			@RequestParam("memberemail") String memberemail,
			@RequestParam("memberphone") int memberphone,
			@RequestParam("membermbti") String membermbti,
			@RequestParam("memberaddr") String memberaddr,
			@RequestParam("aggrement") String aggrement
			) {
				
		int result =ms.memberInsert(memberid, memberpwd, membername, membernickname, membergender, memberbirth, memberemail, memberphone, membermbti, memberaddr, aggrement);
		
		return "redirect:/memberLogin.do";
	}
	//ȸ������
	@RequestMapping(value="/memberProfile.do")
	public String memberProfile(			
			Model model, HttpSession session
 			) {
		int midx = (int)session.getAttribute("midx");
		MemberVo mv = ms.memberSelectOne(midx);
		model.addAttribute("mv", mv);		

		return "memberProfile";
	}
	//�α׾ƿ�
	@RequestMapping(value="/memberLogout.do")
	public String memberLogout(			
			Model model, HttpServletRequest request
 			) {
		HttpSession session = request.getSession();
		session.invalidate();
				

		return "redirect:/index.do";
	}
	
	@RequestMapping(value="/memberFindId.do")
	public String memberFindId() {				
		
		return "memberFindId";
	}
	@RequestMapping(value="/memberFindIdAction.do")
	public String memberFindIdAction(
			@RequestParam("membername") String membername,
			@RequestParam("memberemail") String memberemail,
			Model model) 
	{
	MemberVo mv = ms.memberFindId(membername, memberemail);
	//System.out.println("ms"+ms);
	//System.out.println("�ɹ����̵�"+mv.getMemberid());
	model.addAttribute("mv", mv);
	
		return "memberFindId2";
		
	}@RequestMapping(value="/memberFindId2.do")
	public String memberFindId2() {				
		
		return "memberFindId2";
	}
	@RequestMapping(value="/memberFindPwd.do")
	public String memberFindPwd() {				
		
		return "memberFindPwd";
	}
	@RequestMapping(value="/memberFindPwdAction.do")
	public String memberFindPwdAction(
			@RequestParam("memberid") String memberid,
			@RequestParam("memberemail") String memberemail,
			Model model) 
	{
	MemberVo mv = ms.memberFindPwd(memberid, memberemail);
	//System.out.println("ms"+ms);
	//System.out.println("�ɹ����̵�"+mv.getMemberid());
	model.addAttribute("mv", mv);
	
		return "/memberFindPwd2";
	}
	@RequestMapping(value="/memberFindPwd2.do")
	public String memberFindPwd2() {				
		
		return "memberFindPwd2";
	}
}
